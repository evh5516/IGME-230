// 1
window.onload = getData;

// 2
let displayTerm = "";

// 3
function getData(){
    // 1
    console.log("test");
    const GW2_URL = "https://api.guildwars2.com";

    // 3 - build up our URL string
    let url = GW2_URL;

    /* list of worlds */
    let worldsList = url + "/v2/worlds"


    /* used to fill in the world selector */
    function worldSelection() {
        for (let i = 0; i < worldsList.length; i++){
            let element = document.querySelector("#selection");
            let option = document.createElement("option");
            option.text = worldsList[i];
            element.add(option);
        }
    }
    /*
    $.ajax({
    dataType: "json",
    url: url,
    data: null,
    success: jsonLoaded // 13 - callback function is called when data arrives
}   );*/
}
